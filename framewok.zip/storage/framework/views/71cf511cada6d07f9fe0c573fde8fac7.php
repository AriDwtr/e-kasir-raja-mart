<?php $__env->startSection('konten'); ?>
    <div class="mb-5" id="data-master">
        <?php echo $__env->make('manajemen.datamaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="mb-5" id="data-master">
        <?php echo $__env->make('manajemen.datareport', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="mb-3" id="data-extra">
        <?php echo $__env->make('manajemen.dataextra', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-App\e-Kasir\resources\views/theme/manajemen.blade.php ENDPATH**/ ?>