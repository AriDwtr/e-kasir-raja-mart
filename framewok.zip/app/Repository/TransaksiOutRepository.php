<?php

namespace App\Repository;

use App\Models\BarangModel;
use App\Models\TransaksiOutModel;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class TransaksiOutRepository {

    protected $transaksi;
    protected $barang;

    public function __construct(TransaksiOutModel $transaksi, BarangModel $barang)
    {
        $this->transaksi = $transaksi;
        $this->barang = $barang;
    }

    public function getTransaksiOut() {
        $data = $this->transaksi->join('t_user', 't_user.id', '=', 't_transaksi_out.user')
        ->join('t_barang', 't_barang.kd_brg', '=', 't_transaksi_out.kd_brg')
        ->select('t_transaksi_out.*', 't_user.nm_user', 't_barang.nm_brg')
        ->latest('t_transaksi_out.created_at')
        ->get();

        return $data;
    }


    public function post(array $post)
    {
        $kdbrg = $post['kd_brg'];
        $jmlbrg = $post['jml_brg'];
        $user = Auth::user()->id;
        $data = [];
        foreach ($kdbrg as $index => $barang) {
            $setHrgJual = $this->barang->where('kd_brg', $barang)->first();
            $data[] = [
                'kd_brg' => $barang,
                'jml_brg' => $jmlbrg[$index],
                'hrg_brg_jual' => $setHrgJual->hrg_brg_jual * $jmlbrg[$index],
                'user' => $user,
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now(),
            ];
            // dd($data[$index]['jml_brg']);
            $this->barang->where('kd_brg', $barang)->update(
                [
                    'stok' => DB::raw("stok - $jmlbrg[$index]"),
                ]
            );
        }
        return $this->transaksi::insert($data);
    }
}

?>
